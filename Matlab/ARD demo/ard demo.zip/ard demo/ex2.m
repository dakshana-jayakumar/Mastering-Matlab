clc;
while(1)
    value = readDigitalPin(a,'D2');
    clc;
    disp(value);
        
 end