clear;
clear rpi
rpi = raspi('192.168.1.11','pi','sanjaydchamp'); 
disp(rpi);
for i=1:10
writeDigitalPin(rpi,21,1);
pause(1);
writeDigitalPin(rpi,21,0);
pause(1)
end
