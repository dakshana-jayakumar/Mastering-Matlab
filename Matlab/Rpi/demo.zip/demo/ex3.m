function edgeDetection()
rpi = raspi('192.168.1.11','pi','sanjaydchamp');
w = webcam(rpi);
kern = [1 2 1; 
        0 0 0;
        -1 -2 -1];

for k = 1:1000
      img = snapshot(w);
      h = conv2(img(:,:,2),kern,'same');
      v = conv2(img(:,:,2),kern','same');
      e = sqrt(h.*h + v.*v);
      edgeImg = uint8((e > 100) * 240);
      image(edgeImg);
end
end