function c = average(a,b)

c=(a + b) / 2;

 